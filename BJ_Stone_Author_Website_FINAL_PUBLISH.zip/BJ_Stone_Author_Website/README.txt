BJ Stone Author Website — ready for GitHub Pages

Upload the CONTENTS of this folder to the root of the GitHub Pages repository.
The home page must remain named index.html.

The contact section now has two working options:
1. Email BJ opens the visitor's default email app.
2. Copy Email Address copies author.secretsofshadowvalley@gmail.com.

Book buttons link to the Lulu listings preserved in the latest saved site source.
